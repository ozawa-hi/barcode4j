package com.worksap;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.avalon.framework.configuration.Configuration;
import org.apache.avalon.framework.configuration.ConfigurationException;
import org.apache.avalon.framework.configuration.DefaultConfigurationBuilder;
import org.jdom.output.XMLOutputter;
import org.krysalis.barcode4j.BarcodeException;
import org.krysalis.barcode4j.BarcodeGenerator;
import org.krysalis.barcode4j.BarcodeUtil;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.krysalis.barcode4j.output.svg.JDOMSVGCanvasProvider;
import org.xml.sax.SAXException;

/**
 * generate barcode with barcode4j
 * 
 * @author Hitoshi Ozawa
 * @since  2016/06/29
 */
public class Barcode {
	private static final int DPI = 40;

	/**
	 * Generate barcode using barcode4j
	 * 
	 * @param configFilename	barcode configuration file
	 * @param message			content of barcode
	 * @param outputFilename	filename of barcode file to generate
	 * @param format			output file format (svg, png)
	 * @throws IOException
	 * @throws ConfigurationException
	 * @throws SAXException
	 * @throws BarcodeException
	 */
	public void generateBarcode(String configFilename, String message, String outputFilename, String format) throws IOException, ConfigurationException, SAXException, BarcodeException {
	    switch(format){
	    case "png":
	    	generatePng(configFilename, message, outputFilename+".png");
	    	break;
	    default:
	    	generateSvg(configFilename, message, outputFilename+".svg");
	    	break;
	    }
	}

	/**
	 * Generate barcode as png file
	 * 
	 * @param configFilename	barcode configuration file
	 * @param message			content of barcode
	 * @param outputFilename	filename of barcode file to generate
	 * @throws ConfigurationException
	 * @throws IOException
	 * @throws SAXException
	 * @throws BarcodeException
	 */
	private void generatePng(String configFilename, String message, String outputFilename) throws ConfigurationException, IOException, SAXException, BarcodeException {
	    // load configuration file
		DefaultConfigurationBuilder builder = new DefaultConfigurationBuilder();
	    Configuration cfg = builder.buildFromFile(new File(configFilename));
	    
	    // create barcode generator
	    BarcodeGenerator barcodeBean = BarcodeUtil.getInstance().createBarcodeGenerator(cfg);
		
	    // generate barcode to file
		FileOutputStream outputStream = new FileOutputStream(new File(outputFilename));
		BitmapCanvasProvider canvas = new BitmapCanvasProvider(outputStream, "image/x-png", DPI, BufferedImage.TYPE_BYTE_BINARY, false, 0);
		barcodeBean.generateBarcode(canvas, message);
		canvas.finish();
		outputStream.close();
	}
	
	/**
	 * Generate barcode as svg file
	 * 
	 * @param configFilename	barcode configuration file
	 * @param message			content of barcode
	 * @param outputFilename	filename of barcode file to generate
	 * @throws ConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 * @throws BarcodeException
	 */
	private void generateSvg(String configFilename, String message, String outputFilename) throws ConfigurationException, SAXException, IOException, BarcodeException {
		// load configuration file
		DefaultConfigurationBuilder builder = new DefaultConfigurationBuilder();
	    Configuration cfg = builder.buildFromFile(new File(configFilename));

	    // create barcode generator
	    BarcodeGenerator gen = BarcodeUtil.getInstance().createBarcodeGenerator(cfg);

	    // generate barcode as svg document
		JDOMSVGCanvasProvider provider = new JDOMSVGCanvasProvider(false, 0);
		gen.generateBarcode(provider, message);
		org.jdom.Document doc = provider.getDocument();
		
		// output to file
		FileOutputStream outputStream = new FileOutputStream(new File(outputFilename));
		XMLOutputter outputter = new XMLOutputter();
		outputter.output(doc, outputStream);
		outputStream.close();
	}
}
