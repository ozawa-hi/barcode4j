package com.worksap;

import java.io.IOException;

import org.apache.avalon.framework.configuration.ConfigurationException;
import org.krysalis.barcode4j.BarcodeException;
import org.xml.sax.SAXException;

public class Barcode4jSample {

	public static void main(String[] args) throws ConfigurationException, BarcodeException, IOException, SAXException {
		Barcode barcode = new Barcode();
		barcode.generateBarcode("resources/jppost-cfg-svg.xml", "1076004", "japanPostalSample", "svg");
		
		System.out.println("Finished");
	}
}
